集输工况优化：同样输量怎样少用电
通过老师添加案例选择构建后的完整文件夹。独立运行打开 demo/index.html，三个教学部分均可访问。
数据：固定种子教学夹具，无网络请求。算法、基线与指标由 engine.js 计算。
专业来源：https://www.energy.gov/cmei/ito/pump-systems
改变参数后结果标记过期，重新计算再导出。
