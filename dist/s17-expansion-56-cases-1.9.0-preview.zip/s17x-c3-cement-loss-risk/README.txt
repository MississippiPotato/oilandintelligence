固井漏失风险预测
场景：c3；案例 ID：s17x-c3-cement-loss-risk
打开 demo/index.html，无需网络或后端。通过老师“添加案例”选择包含 case.json、README.txt 和 demo/ 三文件的完整文件夹。
调整压力裕度和判定阈值，比较多变量风险筛查与单压力裕度规则的漏报、误报。
方法：多变量逻辑回归 + 阈值权衡。各输入、计算步骤和评价分母在页面中说明。
专业概念参考：https://www.slb.com/resource-library/oilfield-review/defining-series/defining-cementing
数据：固定种子的教学合成；真实数值算法在浏览器执行。导出 JSON 保存当前参数及实际结果。修改输入会清除旧结果，需重新运行。
验收：本文件不宣称浏览器通过；实际浏览器结果由整站验收报告单独记录。
