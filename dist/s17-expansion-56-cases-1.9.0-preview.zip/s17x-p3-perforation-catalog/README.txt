射孔弹型智能选型：把目录条件变成证据链

案例 ID：s17x-p3-perforation-catalog
老师场景：p3

使用：通过老师原站“添加案例”选择完整案例目录；也可直接离线打开 demo/index.html。默认计算不需要网络、后端或模型密钥。

内容：专业背景解释概念与变量，案例流程逐环节讲输入输出，可运行示范读取当前输入真实计算、比较基线、显示图表和评价，输入修改后结果标记过期。

数据：固定随机种子的合成教学记录。引用资料用于专业概念，未将其描述为实测数据。模型只读取训练记录和观测，评价标签不传入预测入口。

算法：知识约束推理；对照：仅尺寸匹配。
来源：
SLB：perforation https://glossary.slb.com/en/terms/p/perforation
OSHA：perforated completion https://www.osha.gov/etools/oil-and-gas/glossary-of-terms-p

验证边界：源文件生成不等于浏览器验收；实际浏览器记录由汇总交付另附。
